const PERP_TOOL = 'perplexity';
let perp_items = new Set();
let perp_input = '';
document.addEventListener('input', (e) => {
  try {
    const ta = e.target.closest('textarea');
    if (ta) perp_input = ta.value || '';
  } catch (err) {}
}, true);
document.addEventListener('click', (e) => {
  try {
    const btn = e.target.closest('button');
    if (!btn) return;
    const txt = (btn.textContent || btn.getAttribute('aria-label') || '').toLowerCase();
    if (txt.includes('send') || txt.includes('submit')) {
      if (perp_input.trim().length > 5) {
        const key = 'p|' + perp_input.substring(0, 50);
        if (!perp_items.has(key)) {
          perp_items.add(key);
          chrome.runtime.sendMessage({ action: 'capture', data: { type: 'prompt', content: perp_input, aiTool: PERP_TOOL, timestamp: new Date().toISOString(), category: 'General', sessionUrl: window.location.href } });
        }
        perp_input = '';
      }
    }
  } catch (err) {}
}, true);
const perp_obs = new MutationObserver(() => {
  try {
    document.querySelectorAll('[role="article"], .prose, [class*="message"], [data-testid*="message"]').forEach(el => {
      try {
        if (!el.dataset.perpCap) {
          const txt = el.textContent.trim();
          if (txt.length > 20) {
            const key = 'r|' + txt.substring(0, 50);
            if (!perp_items.has(key)) {
              perp_items.add(key);
              el.dataset.perpCap = '1';
              const isUser = el.className.includes('user') || el.getAttribute('data-role') === 'user';
              chrome.runtime.sendMessage({ action: 'capture', data: { type: isUser ? 'prompt' : 'response', content: txt, aiTool: PERP_TOOL, timestamp: new Date().toISOString(), category: 'General', sessionUrl: window.location.href } });
            }
          }
        }
      } catch (e) {}
    });
  } catch (err) {}
});
if (document.body) {
  perp_obs.observe(document.body, { childList: true, subtree: true });
} else {
  document.addEventListener('DOMContentLoaded', () => {
    if (document.body) perp_obs.observe(document.body, { childList: true, subtree: true });
  });
}
