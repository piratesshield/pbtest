// Dashboard State
let allCaptures = [];
let filteredCaptures = [];
let currentPage = 1;
const itemsPerPage = 25;

// Initialize Dashboard
function initDashboard() {
    console.log('Dashboard initializing...');
    setupEventListeners();
    loadCaptures();
    generateSampleData(); // For testing purposes
}

// Setup Event Listeners (NO inline handlers)
function setupEventListeners() {
    // Filter button
    const filterBtn = document.getElementById('filterBtn');
    if (filterBtn) {
        filterBtn.addEventListener('click', applyFilters);
    }

    // Export button
    const exportBtn = document.getElementById('exportBtn');
    if (exportBtn) {
        exportBtn.addEventListener('click', exportData);
    }

    // Clear button
    const clearBtn = document.getElementById('clearBtn');
    if (clearBtn) {
        clearBtn.addEventListener('click', clearData);
    }

    // Search input
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', applyFilters);
    }

    // Pagination buttons
    const prevPage = document.getElementById('prevPage');
    const nextPage = document.getElementById('nextPage');
    if (prevPage) {
        prevPage.addEventListener('click', () => changePage('prev'));
    }
    if (nextPage) {
        nextPage.addEventListener('click', () => changePage('next'));
    }
}

// Load Captures from chrome.storage or chrome.runtime
function loadCaptures() {
    // Check if chrome.runtime is available
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ action: 'getAllCaptures' }, (response) => {
            if (response && response.captures) {
                allCaptures = response.captures;
                applyFilters();
            } else {
                console.log('No captures received from extension');
            }
        });
    } else {
        console.log('Chrome runtime not available - running in standalone mode');
    }
}

// Generate Sample Data for Testing
function generateSampleData() {
    const tools = ['ChatGPT', 'Gemini', 'Perplexity', 'Claude', 'Copilot'];
    const types = ['Prompts', 'Responses'];
    const categories = ['Security', 'Cloud', 'Code', 'AI/ML', 'Data', 'General'];
    
    const sampleCaptures = [];
    for (let i = 0; i < 50; i++) {
        const tool = tools[Math.floor(Math.random() * tools.length)];
        const type = types[Math.floor(Math.random() * types.length)];
        const category = categories[Math.floor(Math.random() * categories.length)];
        
        sampleCaptures.push({
            id: 'capture-' + i,
            type: type,
            tool: tool,
            category: category,
            tokens: Math.floor(Math.random() * 2000) + 100,
            content: `Sample ${type.toLowerCase()} content for ${tool} about ${category}. This is a demonstration of the capture system with various lengths of content.`,
            sessionUrl: `https://chat.example.com/session/${i}`,
            timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString()
        });
    }
    
    allCaptures = sampleCaptures;
    applyFilters();
}

// Apply Filters
function applyFilters() {
    const searchQuery = document.getElementById('searchInput').value.toLowerCase();
    const toolFilter = document.getElementById('toolFilter').value;
    const typeFilter = document.getElementById('typeFilter').value;
    const categoryFilter = document.getElementById('categoryFilter').value;

    filteredCaptures = allCaptures.filter(capture => {
        const matchesSearch = !searchQuery || 
            capture.content.toLowerCase().includes(searchQuery) ||
            capture.tool.toLowerCase().includes(searchQuery) ||
            capture.category.toLowerCase().includes(searchQuery);
        
        const matchesTool = !toolFilter || capture.tool === toolFilter;
        const matchesType = !typeFilter || capture.type === typeFilter;
        const matchesCategory = !categoryFilter || capture.category === categoryFilter;

        return matchesSearch && matchesTool && matchesType && matchesCategory;
    });

    currentPage = 1;
    updateStats();
    renderTable();
    renderPagination();
}

// Update Stats Cards
function updateStats() {
    const totalCount = filteredCaptures.length;
    const promptCount = filteredCaptures.filter(c => c.type === 'Prompts').length;
    const responseCount = filteredCaptures.filter(c => c.type === 'Responses').length;
    const tokenCount = filteredCaptures.reduce((sum, c) => sum + (c.tokens || 0), 0);

    document.getElementById('totalCount').textContent = totalCount;
    document.getElementById('tokenCount').textContent = tokenCount.toLocaleString();
    document.getElementById('promptCount').textContent = promptCount;
    document.getElementById('responseCount').textContent = responseCount;
}

// Render Table
function renderTable() {
    const tbody = document.getElementById('tableBody');
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageCaptures = filteredCaptures.slice(startIndex, endIndex);

    if (pageCaptures.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="no-data">No captures found. Try adjusting your filters.</td></tr>';
        return;
    }

    tbody.innerHTML = pageCaptures.map(capture => {
        const toolBadgeClass = 'badge-' + capture.tool.toLowerCase().replace(/\s+/g, '');
        const typeBadgeClass = capture.type === 'Prompts' ? 'badge-prompt' : 'badge-response';
        const timeFormatted = formatTimestamp(capture.timestamp);

        return `
            <tr>
                <td><span class="badge ${typeBadgeClass}">${capture.type}</span></td>
                <td><span class="badge ${toolBadgeClass}">${capture.tool}</span></td>
                <td>${capture.category}</td>
                <td>${capture.tokens ? capture.tokens.toLocaleString() : 'N/A'}</td>
                <td class="content-cell" title="${escapeHtml(capture.content)}">${escapeHtml(capture.content)}</td>
                <td><a href="${escapeHtml(capture.sessionUrl)}" class="link-btn" target="_blank">🔗 Open</a></td>
                <td>${timeFormatted}</td>
            </tr>
        `;
    }).join('');
}

// Render Pagination
function renderPagination() {
    const totalPages = Math.ceil(filteredCaptures.length / itemsPerPage);
    const paginationNumbers = document.getElementById('paginationNumbers');
    const prevBtn = document.getElementById('prevPage');
    const nextBtn = document.getElementById('nextPage');

    // Update button states
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === totalPages || totalPages === 0;

    // Generate page numbers
    const pageButtons = [];
    const maxButtons = 7;
    let startPage = Math.max(1, currentPage - Math.floor(maxButtons / 2));
    let endPage = Math.min(totalPages, startPage + maxButtons - 1);

    if (endPage - startPage < maxButtons - 1) {
        startPage = Math.max(1, endPage - maxButtons + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
        const activeClass = i === currentPage ? 'active' : '';
        pageButtons.push(`<button class="page-number ${activeClass}" data-page="${i}">${i}</button>`);
    }

    paginationNumbers.innerHTML = pageButtons.join('');

    // Add event listeners to page number buttons
    paginationNumbers.querySelectorAll('.page-number').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const page = parseInt(e.target.getAttribute('data-page'));
            if (page && page !== currentPage) {
                currentPage = page;
                renderTable();
                renderPagination();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    });
}

// Change Page
function changePage(direction) {
    const totalPages = Math.ceil(filteredCaptures.length / itemsPerPage);
    
    if (direction === 'prev' && currentPage > 1) {
        currentPage--;
    } else if (direction === 'next' && currentPage < totalPages) {
        currentPage++;
    }

    renderTable();
    renderPagination();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Export Data
function exportData() {
    if (filteredCaptures.length === 0) {
        showToast('⚠️ No data to export');
        return;
    }

    const dataStr = JSON.stringify(filteredCaptures, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ai-captures-${Date.now()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showToast(`✓ Exported ${filteredCaptures.length} captures`);
}

// Clear Data
function clearData() {
    if (allCaptures.length === 0) {
        showToast('⚠️ No data to clear');
        return;
    }

    if (confirm(`Are you sure you want to delete all ${allCaptures.length} captures? This action cannot be undone.`)) {
        // Try to clear from chrome.storage if available
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage({ action: 'clearAllCaptures' }, (response) => {
                if (response && response.success) {
                    allCaptures = [];
                    applyFilters();
                    showToast('✓ All captures cleared');
                }
            });
        } else {
            // Clear local data
            allCaptures = [];
            applyFilters();
            showToast('✓ All captures cleared');
        }
    }
}

// Show Toast Notification
function showToast(message) {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    toastMessage.textContent = message;
    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Format Timestamp
function formatTimestamp(timestamp) {
    if (!timestamp) return 'N/A';
    
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

// Escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Initialize on DOM load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initDashboard);
} else {
    initDashboard();
}