const CLAUDE_TOOL = 'claude';
let claude_items = new Set();
let claude_input = '';
document.addEventListener('input', (e) => {
  try {
    const ta = e.target.closest('textarea');
    const inp = e.target.closest('input[type="text"]');
    if (ta) claude_input = ta.value || '';
    else if (inp) claude_input = inp.value || '';
  } catch (err) {}
}, true);
document.addEventListener('click', (e) => {
  try {
    const btn = e.target.closest('button');
    if (!btn) return;
    const txt = (btn.textContent || btn.getAttribute('aria-label') || btn.getAttribute('data-action') || '').toLowerCase();
    if (txt.includes('send') || txt.includes('submit')) {
      if (claude_input.trim().length > 5) {
        const key = 'p|' + claude_input.substring(0, 50);
        if (!claude_items.has(key)) {
          claude_items.add(key);
          chrome.runtime.sendMessage({ action: 'capture', data: { type: 'prompt', content: claude_input, aiTool: CLAUDE_TOOL, timestamp: new Date().toISOString(), category: 'General', sessionUrl: window.location.href } });
        }
        claude_input = '';
      }
    }
  } catch (err) {}
}, true);
const claude_obs = new MutationObserver(() => {
  try {
    document.querySelectorAll('[role="article"], [data-testid*="message"], [class*="message"], .rounded-lg').forEach(el => {
      try {
        if (!el.dataset.claudeCap) {
          const txt = el.textContent.trim();
          if (txt.length > 20 && txt.length < 50000) {
            const key = 'r|' + txt.substring(0, 50);
            if (!claude_items.has(key)) {
              claude_items.add(key);
              el.dataset.claudeCap = '1';
              const isUser = el.className.includes('user') || el.getAttribute('data-role') === 'user' || el.getAttribute('data-type') === 'prompt';
              chrome.runtime.sendMessage({ action: 'capture', data: { type: isUser ? 'prompt' : 'response', content: txt, aiTool: CLAUDE_TOOL, timestamp: new Date().toISOString(), category: 'General', sessionUrl: window.location.href } });
            }
          }
        }
      } catch (e) {}
    });
  } catch (err) {}
});
if (document.body) {
  claude_obs.observe(document.body, { childList: true, subtree: true });
} else {
  document.addEventListener('DOMContentLoaded', () => {
    if (document.body) claude_obs.observe(document.body, { childList: true, subtree: true });
  });
}
setTimeout(() => {
  try {
    document.querySelectorAll('[role="article"], [data-testid*="message"]').forEach(el => {
      try {
        if (!el.dataset.claudeCap) {
          const txt = el.textContent.trim();
          if (txt.length > 20) {
            el.dataset.claudeCap = '1';
            const isUser = el.className.includes('user');
            chrome.runtime.sendMessage({ action: 'capture', data: { type: isUser ? 'prompt' : 'response', content: txt, aiTool: CLAUDE_TOOL, timestamp: new Date().toISOString(), category: 'General', sessionUrl: window.location.href } });
          }
        }
      } catch (e) {}
    });
  } catch (e) {}
}, 1000);
