chrome.runtime.onMessage.addListener((req, sender, res) => {
  if (req.action === 'capture') {
    chrome.storage.local.get(['captures'], (r) => {
      const captures = r.captures || [];
      const tokens = Math.max(
        Math.ceil((req.data.content.split(/\s+/).length) * 1.3),
        Math.ceil((req.data.content.length) * 0.25)
      );
      captures.push({ ...req.data, tokens });
      chrome.storage.local.set({ captures });
      chrome.action.setBadgeText({ text: captures.length.toString() });
      chrome.action.setBadgeBackgroundColor({ color: '#c41e3a' });
    });
  }
  if (req.action === 'getStats') {
    chrome.storage.local.get(['captures'], (r) => {
      const captures = r.captures || [];
      res({
        success: true,
        data: {
          total: captures.length,
          totalTokens: captures.reduce((s, c) => s + (c.tokens || 0), 0),
          prompts: captures.filter(c => c.type === 'prompt').length
        }
      });
    });
  }
  if (req.action === 'getAllCaptures') {
    chrome.storage.local.get(['captures'], (r) => {
      res({ success: true, data: r.captures || [] });
    });
  }
  if (req.action === 'clearAll') {
    chrome.storage.local.set({ captures: [] });
    chrome.action.setBadgeText({ text: '' });
    res({ success: true });
  }
  return true;
});
