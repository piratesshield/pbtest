const GEMINI_TOOL = 'gemini';
let gemini_items = new Set();
let gemini_input = '';
document.addEventListener('input', (e) => {
  try {
    if (e.target.closest('textarea')) gemini_input = e.target.value || '';
  } catch (err) {}
}, true);
document.addEventListener('click', (e) => {
  try {
    const btn = e.target.closest('button');
    if (!btn) return;
    if (btn.getAttribute('aria-label')?.includes('Send') || btn.textContent.includes('Send')) {
      if (gemini_input.trim().length > 5) {
        const key = 'p|' + gemini_input.substring(0, 50);
        if (!gemini_items.has(key)) {
          gemini_items.add(key);
          chrome.runtime.sendMessage({ action: 'capture', data: { type: 'prompt', content: gemini_input, aiTool: GEMINI_TOOL, timestamp: new Date().toISOString(), category: 'General', sessionUrl: window.location.href } });
        }
        gemini_input = '';
      }
    }
  } catch (err) {}
}, true);
const gemini_obs = new MutationObserver(() => {
  try {
    document.querySelectorAll('[role="article"], [class*="message"], .prose').forEach(el => {
      try {
        if (!el.dataset.geminiCap) {
          const txt = el.textContent.trim();
          if (txt.length > 20) {
            const key = 'r|' + txt.substring(0, 50);
            if (!gemini_items.has(key)) {
              gemini_items.add(key);
              el.dataset.geminiCap = '1';
              const isUser = el.className.includes('user');
              chrome.runtime.sendMessage({ action: 'capture', data: { type: isUser ? 'prompt' : 'response', content: txt, aiTool: GEMINI_TOOL, timestamp: new Date().toISOString(), category: 'General', sessionUrl: window.location.href } });
            }
          }
        }
      } catch (e) {}
    });
  } catch (err) {}
});
if (document.body) {
  gemini_obs.observe(document.body, { childList: true, subtree: true });
} else {
  document.addEventListener('DOMContentLoaded', () => {
    if (document.body) gemini_obs.observe(document.body, { childList: true, subtree: true });
  });
}
