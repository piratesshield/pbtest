const CHAT_TOOL = 'chatgpt';
let chat_items = new Set();
let chat_input = '';
document.addEventListener('input', (e) => {
  try {
    if (e.target.closest('textarea')) chat_input = e.target.value || '';
  } catch (err) {}
}, true);
document.addEventListener('click', (e) => {
  try {
    const btn = e.target.closest('button');
    if (!btn) return;
    const txt = (btn.textContent || btn.getAttribute('aria-label') || '').toLowerCase();
    if (txt.includes('send') || txt.includes('submit')) {
      if (chat_input.trim().length > 5) {
        const key = 'p|' + chat_input.substring(0, 50);
        if (!chat_items.has(key)) {
          chat_items.add(key);
          chrome.runtime.sendMessage({ action: 'capture', data: { type: 'prompt', content: chat_input, aiTool: CHAT_TOOL, timestamp: new Date().toISOString(), category: 'General', sessionUrl: window.location.href } });
        }
        chat_input = '';
      }
    }
  } catch (err) {}
}, true);
const chat_obs = new MutationObserver(() => {
  try {
    document.querySelectorAll('[role="article"], [data-testid*="message"], .prose').forEach(el => {
      try {
        if (!el.dataset.chatCap) {
          const txt = el.textContent.trim();
          if (txt.length > 20) {
            const key = 'r|' + txt.substring(0, 50);
            if (!chat_items.has(key)) {
              chat_items.add(key);
              el.dataset.chatCap = '1';
              const isUser = el.className.includes('user') || el.getAttribute('data-role') === 'user';
              chrome.runtime.sendMessage({ action: 'capture', data: { type: isUser ? 'prompt' : 'response', content: txt, aiTool: CHAT_TOOL, timestamp: new Date().toISOString(), category: 'General', sessionUrl: window.location.href } });
            }
          }
        }
      } catch (e) {}
    });
  } catch (err) {}
});
if (document.body) {
  chat_obs.observe(document.body, { childList: true, subtree: true });
} else {
  document.addEventListener('DOMContentLoaded', () => {
    if (document.body) chat_obs.observe(document.body, { childList: true, subtree: true });
  });
}
