const COPILOT_TOOL = 'copilot';
let copilot_items = new Set();
let copilot_input = '';
document.addEventListener('input', (e) => {
  try {
    const ta = e.target.closest('textarea');
    if (ta) copilot_input = ta.value || '';
  } catch (err) {}
}, true);
document.addEventListener('click', (e) => {
  try {
    const btn = e.target.closest('button');
    if (!btn) return;
    if (btn.getAttribute('aria-label')?.includes('Send')) {
      if (copilot_input.trim().length > 5) {
        const key = 'p|' + copilot_input.substring(0, 50);
        if (!copilot_items.has(key)) {
          copilot_items.add(key);
          chrome.runtime.sendMessage({ action: 'capture', data: { type: 'prompt', content: copilot_input, aiTool: COPILOT_TOOL, timestamp: new Date().toISOString(), category: 'General', sessionUrl: window.location.href } });
        }
        copilot_input = '';
      }
    }
  } catch (err) {}
}, true);
const copilot_obs = new MutationObserver(() => {
  try {
    document.querySelectorAll('[role="article"], [class*="message"]').forEach(el => {
      try {
        if (!el.dataset.copilotCap) {
          const txt = el.textContent.trim();
          if (txt.length > 20) {
            const key = 'r|' + txt.substring(0, 50);
            if (!copilot_items.has(key)) {
              copilot_items.add(key);
              el.dataset.copilotCap = '1';
              const isUser = el.className.includes('user');
              chrome.runtime.sendMessage({ action: 'capture', data: { type: isUser ? 'prompt' : 'response', content: txt, aiTool: COPILOT_TOOL, timestamp: new Date().toISOString(), category: 'General', sessionUrl: window.location.href } });
            }
          }
        }
      } catch (e) {}
    });
  } catch (err) {}
});
if (document.body) {
  copilot_obs.observe(document.body, { childList: true, subtree: true });
} else {
  document.addEventListener('DOMContentLoaded', () => {
    if (document.body) copilot_obs.observe(document.body, { childList: true, subtree: true });
  });
}
